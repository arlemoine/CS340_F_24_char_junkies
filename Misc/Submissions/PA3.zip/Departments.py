
#%% MODULE BEGINS
module_name = 'Departments'

'''
Version: 1.1

Description:
    Module to consolidate fitness data for individuals into their department. Generates fitness statistics for the department based off of the individuals and produces relevant graphs.

Authors:
    Adriean Lemoine
    Chris Smith

Date Created     :  11/26/2024
Date Last Updated:  11/30/2024
'''

#%% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
   import os
   #os.chdir("./../..")
#

#custom imports
import Logging

#other imports  
import contextlib as clib # Used to redirect output stream from terminal to a file for saving individual info
from   copy       import deepcopy as dpcpy
from   matplotlib import pyplot as plt
import math
import numpy  as np 
import os
import pandas as pd
import pickle as pkl
import seaborn as sns
from Individuals import FitnessDataProcessing
from tabulate import tabulate
import logging

#%% CONSTANTS                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

import Config

#%% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Global declarations Start Here


#Class definitions Start Here

class DepartmentData:
    def __init__(self, departmentName, daysInMonth=31):
        self.departmentName = departmentName
        self.individuals = {}
        self.daysInMonth = daysInMonth

        self.df_dept_steps = None # Steps per day average per individual for department
        self.df_dept_hrv = None # HRV average per individual for department
        self.df_dept_fitness_scores = None # Fitness score average per individual
        self.df_dept_age = None # Age per individual

        self.logger = Logging.configure_logger(self.departmentName)
    #

    # Add person to group       
    def addIndividual(self, individual):
        self.individuals[individual.name] = individual
    #

    # Remove person from group                                          
    def dropIndividual(self, individual):
        if individual.name in self.individuals:
            del self.individuals[individual.name]
        else:
            print(f'Individual named {individual.name} not found in department.')
    #

    # Examine each individual's HRV table to determine the max 'dayOfMonth' for each person.
    def calcDays(self):
        
        max_days = [] 
    
        
        for individual in self.individuals.values():
            if individual.df_hrv is not None and not individual.df_hrv.empty:
               
                max_day_of_month = individual.df_hrv['dayOfMonth'].max()
                max_days.append(max_day_of_month)  

        if max_days:
            days_accounted_for = min(max_days) # Use the minimum from all individuals' max values to determine the number of days accounted for
        else:
            days_accounted_for = 0

        return days_accounted_for
    #

    # Create all dataframes
    def getDataframes(self):
        self.df_dept_steps = self.getSteps()
        self.df_dept_hrv = self.getHRV()
        self.df_dept_fitness_scores = self.getFitnessScores()
        self.df_dept_age = self.getAges()
    #

    # Generate a DataFrame for the average steps per person in the department.
    def getSteps(self):
        names = []
        avgSteps = []
        department_name = self.departmentName

        for individual in self.individuals.values():
            # individual.calc_step_score()
            # avgSteps_value = round(float(individual.avg_steps), 2)
            names.append(individual.name)
            avgSteps.append(individual.avg_steps)
        #

        self.df_dept_steps = pd.DataFrame({
            'deptName': [department_name] * len(names),
            'indName': [name.capitalize() for name in names],
            'avgSteps': avgSteps
        })

        return self.df_dept_steps
    #

    # Generate a DataFrame for the average HRV per person in the department.
    def getHRV(self):
        names = []
        avgHRV = []
        department_name = self.departmentName

        for individual in self.individuals.values():
            # individual.calc_hrv_score()
            # avgHRV_value = round(float(individual.avg_hrv), 2)
            names.append(individual.name)
            avgHRV.append(individual.avg_hrv)
        #

        self.df_dept_hrv = pd.DataFrame({
            'deptName': [department_name] * len(names),
            'indName': [name.capitalize() for name in names],
            'avgHRV': avgHRV
        })

        return self.df_dept_hrv
    #

    # Generates a dataframe that shows the average fitness score for the department
    def getFitnessScores(self):
        names = []
        fitness_scores = []  
        department_name = self.departmentName 
        probation_score = Config.PROB_FITNESS_SCORE
        min_fitness_score = Config.MIN_FITNESS_SCORE 

        for individual in self.individuals.values():
            # individual.calc_fitness_score()
            # fitness_score_value = round(float(individual.fitness_score), 2)
            names.append(individual.name)
            fitness_scores.append(individual.fitness_score)
        #
    
        self.df_dept_fitness_scores = pd.DataFrame({
            'deptName': [department_name] * len(names),
            'indName': [name.capitalize() for name in names],
            'fitnessScore': fitness_scores
        })

        # Categorizing each individual as 'Pass', 'Probation', or 'Fail'.
        self.df_dept_fitness_scores['fitnessGroup'] = self.df_dept_fitness_scores['fitnessScore'].apply(
            lambda x: 'Pass' if x >= probation_score else ('Probation' if x >= min_fitness_score else 'Fail')
        )

        return self.df_dept_fitness_scores
    #

    # Creates a dataframe that shows the average age of the department
    def getAges(self):
        names = []
        ages = []
        age_status = []  # To store the status of each individual

        for individual in self.individuals.values():
            names.append(individual.name)
            ages.append(individual.age)

            # Check if the individual is above or below the age of 35
            if individual.age > 35:
                age_status.append("Above 35")
            else:
                age_status.append("Below 35")

        # Create a DataFrame with the data
        df_dept_age = pd.DataFrame({
            'deptName': [self.departmentName] * len(names),
            'indName': [name.capitalize() for name in names],
            'age': ages,
            'ageGroup': age_status
        })

        return df_dept_age
    #
#

# Child class to process and save data for department variables
class DepartmentDataProcessing(DepartmentData):
    def __init__(self, departmentName, daysInMonth):
        super().__init__(departmentName, daysInMonth)
        self.config = {
            "DIR_OUTPUT": Config.DIR_OUTPUT
        }
        self.dataFile = f'{departmentName}.pkl' # Create filename for pickle file
        self.updateDirectory()

        # Stats from dataframes
        self.df_stats_steps = None
        self.df_stats_hrv = None
        self.df_stats_fitness_score = None
        self.df_stats_age = None
    #

    # Create folder for dept in Output folder
    def updateDirectory(self):
        path = f"{self.config['DIR_OUTPUT']}/{self.departmentName}"

        if not os.path.exists(path):
            os.makedirs(path)
        #
    #
   
   # Write all data to proper files
    def writeAll(self):
        self.getDataframes()
        self.logger.info('Data retrieved for individuals.')
        self.calcDays()
        self.getStats_all()
        self.logger.info('Statistics generated from data.')
        self.gen_dept_hist()
        self.logger.info('Histograms created.')
        self.gen_dept_vectors()
        self.logger.info('Vector graphs created for individuals.')
        self.writeStats()
        self.logger.info('Department data written to output folder.')
        self.pickleSave()
        self.logger.info('Department saved to pickle file.')
    #

    def getStats_all(self):
        self.getStats_steps()
        self.getStats_hrv()
        self.getStats_fitness_score()
        self.getStats_age()

    # Generates dataframe for step statistics
    def getStats_steps(self):
        if self.df_dept_steps is None or self.df_dept_steps.empty:
            self.getSteps()
        #
        if self.df_dept_steps.empty:
            return None
        #

        self.df_stats_steps = self.df_dept_steps.describe() # NEWLY ADDED

        # BELOW SHOULD NOT BE NEEDED. ONLY NEED TO USE DESCRIBE()

        # min_steps = round(self.df_dept_steps['avgSteps'].min(), 2)
        # mean_steps = round(self.df_dept_steps['avgSteps'].mean(), 2)
        # median_steps = round(self.df_dept_steps['avgSteps'].median(), 2)
        # mode_steps = self.df_dept_steps['avgSteps'].mode()
        # mode_steps = round(mode_steps[0], 2) if not mode_steps.empty else np.nan
        # max_steps = round(self.df_dept_steps['avgSteps'].max(), 2)

        # stats_df = pd.DataFrame({
        #      'deptName': [self.departmentName] * 5,
        #     'Statistic': ['Min', 'Mean', 'Median', 'Mode', 'Max'],
        #     'Steps': [min_steps, mean_steps, median_steps, mode_steps, max_steps]
        # })

        # return stats_df
    #

    # Generates dataframe for HRV statistics
    def getStats_hrv(self):
        if self.df_dept_hrv is None or self.df_dept_hrv.empty:
            self.getHRV()
        #
        if self.df_dept_hrv.empty:
            return None
        #

        self.df_stats_hrv = self.df_dept_hrv.describe() # NEWLY ADDED
    
        # BELOW SHOULD NOT BE NEEDED. ONLY NEED TO USE DESCRIBE()

        # min_hrv = round(self.df_dept_hrv['avgHRV'].min(),2)
        # mean_hrv = round(self.df_dept_hrv['avgHRV'].mean(), 2)
        # median_hrv = round(self.df_dept_hrv['avgHRV'].median(), 2)
        # mode_hrv = round(self.df_dept_hrv['avgHRV'].mode(), 2)
        # mode_hrv = mode_hrv[0] if not mode_hrv.empty else np.nan
        # max_hrv = round(self.df_dept_hrv['avgHRV'].max(),2)

        # stats_df_hrv = pd.DataFrame({
        #     'deptName': [self.departmentName] * 5,
        #     'Statistic': ['Min', 'Mean', 'Median', 'Mode', 'Max'],
        #     'HRV': [min_hrv, mean_hrv, median_hrv, mode_hrv, max_hrv]
        # })

        # return stats_df_hrv
    #

    # Generates dataframe for fitness score statistics
    def getStats_fitness_score(self):
        if self.df_dept_fitness_scores is None or self.df_dept_fitness_scores.empty:
            self.getFitnessScores() 
        #
        if self.df_dept_fitness_scores.empty:
            return None
        #

        self.df_stats_fitness_score = self.df_dept_fitness_scores.describe() # NEWLY ADDED

        # BELOW SHOULD NOT BE NEEDED. ONLY NEED TO USE DESCRIBE()

        # min_fitness_score = round(self.df_dept_fitness_scores['fitnessScore'].min(), 2)
        # mean_fitness_score = round(self.df_dept_fitness_scores['fitnessScore'].mean(), 2)
        # median_fitness_score = round(self.df_dept_fitness_scores['fitnessScore'].median(), 2)
        # mode_fitness_score = round(self.df_dept_fitness_scores['fitnessScore'].mode(),2)
        # mode_fitness_score = mode_fitness_score[0] if not mode_fitness_score.empty else np.nan
        # max_fitness_score = round(self.df_dept_fitness_scores['fitnessScore'].max(),2)

        # stats_df = pd.DataFrame({
        #     'deptName': [self.departmentName] * 5,
        #     'Statistic': ['Min', 'Mean', 'Median', 'Mode', 'Max'],
        #     'Fitness_Score': [min_fitness_score, mean_fitness_score, median_fitness_score, mode_fitness_score, max_fitness_score]
        # })

        # return stats_df
    #

    # Generates dataframe for age statistics
    def getStats_age(self):
        if self.df_dept_age is None or self.df_dept_age.empty:
            self.getAges() 
        #
        # if self.df_dept_age.empty:
        #     return None
        # #

        self.df_stats_age = self.df_dept_age.describe() # NEWLY ADDED

    # Generate subplots for histograms of data
    def gen_dept_hist(self):
        graph_dir = f"{self.config['DIR_OUTPUT']}{self.departmentName}/"

        # Prepare data for histograms
        if self.df_dept_steps is None:
            self.getSteps()
        if self.df_dept_hrv is None:
            self.getHRV()
        if self.df_dept_fitness_scores is None:
            self.getFitnessScores()
        avgSteps = self.df_dept_steps['avgSteps']
        avgHRV = self.df_dept_hrv['avgHRV']
        fitness_scores = self.df_dept_fitness_scores['fitnessScore']
        ages = [indiv.age for indiv in self.individuals.values()]

        # Create a single figure with subplots
        fig, axs = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle(f"Histograms for Department: {self.departmentName}", fontsize=16)

        # Histogram for Average Steps
        axs[0, 0].hist(avgSteps, bins=5, alpha=0.7, edgecolor='black')
        axs[0, 0].set_title("Average Steps per Individual")
        axs[0, 0].set_xlabel("Average Steps")
        axs[0, 0].grid(axis='y', linestyle='--', alpha=0.7)

        # Histogram for Average HRV
        axs[0, 1].hist(avgHRV, bins=4, alpha=0.7, edgecolor='black')
        axs[0, 1].set_title("Average HRV per Individual")
        axs[0, 1].set_xlabel("Average HRV")
        axs[0, 1].grid(axis='y', linestyle='--', alpha=0.7)

        # Histogram for Fitness Score
        axs[1, 0].hist(fitness_scores, bins=5, alpha=0.7, edgecolor='black')
        axs[1, 0].set_title("Fitness Score per Individual")
        axs[1, 0].set_xlabel("Fitness Score")
        axs[1, 0].grid(axis='y', linestyle='--', alpha=0.7)

        # Histogram for Age
        axs[1, 1].hist(ages, bins=5, alpha=0.7, edgecolor='black')
        axs[1, 1].set_title("Age per Individual")
        axs[1, 1].set_xlabel("Age")
        axs[1, 1].grid(axis='y', linestyle='--', alpha=0.7)

        plt.tight_layout(rect=[0, 0, 1, 0.95])
        output_path = os.path.join(graph_dir, "histograms.png")
        plt.savefig(output_path)
        plt.close()

        print(f"Combined histograms saved at: {output_path}")
    #

    def gen_dept_vectors(self):
        avgAge = self.df_stats_age.loc['mean','age']
        avgFitnessScore = self.df_stats_fitness_score.loc['mean','fitnessScore']
        print(f'Average age: {avgAge}\nFitness score: {avgFitnessScore}')

        for person in self.individuals.values():
            self.gen_vectors(person, avgAge, avgFitnessScore)
        #

    def gen_vectors(self, person, avgAge, avgFitnessScore):
        def project_vector(v, u):
            '''
            Projects vector v onto vector u.
            v: The vector to be projected.
            u: The vector onto which v is projected.
            '''
            
            # Calculate the dot product of v and u
            dot_product = np.dot(v, u)
        
            # Calculate the magnitude of u squared
            magnitude_squared = np.dot(u, u)
            
            # Check if the magnitude squared of u is not zero
            if magnitude_squared == 0:
                raise ValueError("Cannot project onto a zero vector.")
            
            # Calculate the projection
            projection = (dot_product / magnitude_squared) * u
            return projection
        #
        
        # Define vectors
        origin = np.array([0,0])
        proj_v1 = np.array([avgAge,avgFitnessScore]) # Vector representing departmental average
        proj_v2 = np.array([person.age,person.fitness_score]) # Vector representing individual
        proj_v3 = project_vector(proj_v2, proj_v1) # Projection vector
        angle_v1 = proj_v1 / np.linalg.norm(proj_v1)
        angle_v2 = proj_v2 / np.linalg.norm(proj_v2)
        
        # Generate and configure subplots
        fig, axs = plt.subplots(1,2,figsize=(10,4))
        axs[0].set_xlim(0,65)
        axs[0].set_ylim(0,2000)
        axs[1].set_xlim(0,.1)
        axs[1].set_ylim(0,1)
        axs[0].set_title('Projection Vector')
        axs[1].set_title('Departure Angle')
        
        # Generate vectors for subplot 1
        axs[0].quiver(origin[0], origin[1], proj_v1[0], proj_v1[1], angles='xy', scale_units='xy', scale=1, color='b', label='Average')
        axs[0].quiver(origin[0], origin[1], proj_v2[0], proj_v2[1], angles='xy', scale_units='xy', scale=1, color='g', label='Individual')
        axs[0].quiver(origin[0], origin[1], proj_v3[0], proj_v3[1], angles='xy', scale_units='xy', scale=1, color='r', label='Projection')
        
        # Generate vectors for subplot 2
        axs[1].quiver(origin[0], origin[1], angle_v1[0], angle_v1[1], angles='xy', scale_units='xy', scale=1, color='b', label='Average')
        axs[1].quiver(origin[0], origin[1], angle_v2[0], angle_v2[1], angles='xy', scale_units='xy', scale=1, color='g', label='Individual')
        
        # Apply legend
        axs[0].legend()
        axs[1].legend()

        # Update individual departure angle
        person.departureAngle = np.arccos(np.dot(angle_v1, angle_v2)) * 180 / math.pi

        # Save figure as png
        fig.savefig(f"{self.config['DIR_OUTPUT']}/{person.name}/vectors.png")
        person.logger.info('Vector graph saved to output folder.')
    #

    # Writes out the departments stats to a file
    def writeStats(self):
        dataFile = f'Output/{self.departmentName}/data.txt'
        with open(dataFile, "w") as f:
            with clib.redirect_stdout(f):
                print(f'Department Name:\t{self.departmentName}')
                print(f'People:')
                for person in self.individuals.values():
                    print(f'\t{person.name}')
                #
                print(f'\nSTATISTICS\n===========')
                print(f'\n{self.df_stats_steps}')
                print(f'\n{self.df_stats_hrv}')
                print(f'\n{self.df_stats_fitness_score}')
                print(f'\n{self.df_stats_age}')
                print(f'\nDATA\n=====')
                print(f'\n{self.df_dept_steps}')
                print(f'\n{self.df_dept_hrv}')
                print(f'\n{self.df_dept_fitness_scores}')
                print(f'\n{self.df_dept_age}')
            #
        #
    #

    # Saves the departments data to a pickle file
    def pickleSave(self):
        # DEfines the pickle file  name based on the deptName
        pickle_filename = f"{self.departmentName}.pickle"
        # Constructs the output path where the pickle file will be saved
        output_path = os.path.join(self.config['DIR_OUTPUT'], self.departmentName, pickle_filename)
        # Create the directories leading to the file path
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        try:
            with open(output_path, 'wb') as f:
                pkl.dump(self, f)
            print(f"Department saved successfully to {output_path}")
        except Exception as e:
            print(f"Error saving department to pickle: {e}")
    #

    # Loads the departments data from pickle file
    def pickleLoad(pickle_file_path):
        try:
            # Open the pickle file in read-binary mode
            with open(pickle_file_path, 'rb') as f:
                # Load the data from the pickle file
                department = pkl.load(f)
        
            # Return the loaded department data
            return department

        except FileNotFoundError:
            print(f"Error: The file '{pickle_file_path}' was not found.")
        except pkl.UnpicklingError:
            print(f"Error: There was an issue unpickling the file '{pickle_file_path}'.")
        except Exception as e:
            print(f"An error occurred: {e}")
    #
#

if __name__ == "__main__":

# Creates the department and adds the departments name, daysInMonth, and individuals
    dept1 = DepartmentDataProcessing('CMPSPD 340', daysInMonth=30)
    
# Create instances of FitnessDataProcessing (each individual)
    person1 = FitnessDataProcessing('adam')
    person2 = FitnessDataProcessing('brian')
    person3 = FitnessDataProcessing('charlie')
    person4 = FitnessDataProcessing('david')
    person5 = FitnessDataProcessing('eddie')

# Add individuals to the department
    dept1.addIndividual(person1)
    dept1.addIndividual(person2)
    dept1.addIndividual(person3)
    dept1.addIndividual(person4)
    dept1.addIndividual(person5)

    dept1.writeAll()

# Get the average age for each department
    # df_dept_age = dept1.getAges()

# # Loading the data from the pickle file
#     dept1_data = DepartmentDataProcessing.pickleLoad(pickle_file_path)
  
    



# # Display the department's average steps per individual
#     print(f"Days accounted for: {days_accounted_for}")
#     print(tabulate(steps_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(hrv_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(fitnessScores_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(df_dept_age, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(stats_steps_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(stats_HRV_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
#     print(tabulate(stats_fitnessScores_df, headers='keys', tablefmt='fancy_grid', numalign='center', stralign='center'))
    
    
