# char_junkies_project
CMPS 340 Project

Members:
- Nicholas Burgo
- Chris Smith
- Adriean Lemoine

## Premise of Project

It is believed that the methods of ensuring police officer fitness level are inadequate to guarantee a proper police force. More specifically, it is not enough to give a fitness test to each officer once a year, as an annual fitness test does not guarantee an active lifestyle and oveall indicator of officer health. 

We attempt to solve this problem by the utilization of fitbits in the department. Each officer has their steps, heart rate variability, and heart rate continuously monitored and assessed to calculate a fitness score. If the fitness score is below a standard minimum fitness score, the officer is placed on probation. 

This information can be used to determine how far from the standard each officer is. It can 
also be used to project future fitness statistics, including the likelihood that a new officer would meet the fitness standards.
